# Parry Mobile UI v3 — protótipo de treino

Configuração inicial: alcance de referência **30 cm** e perfil **TARDIO**.
Interface compacta para celular, com controles Auto Parry / Perfect Parry apenas demonstrativos, ajuste de alcance, seletor de perfil, teste de configuração, arrastar e minimizar.

**Limitação:** não detecta a bola real, não aciona parry no Death Ball e não contém bypass de anti-cheat. O alcance em centímetros é apenas um valor de referência visual, não uma medida do mundo do jogo.

## Publicar
Envie `loader_v3.lua` para um novo repositório GitHub. Abra o arquivo, toque em Raw e copie a URL `raw.githubusercontent.com`.
